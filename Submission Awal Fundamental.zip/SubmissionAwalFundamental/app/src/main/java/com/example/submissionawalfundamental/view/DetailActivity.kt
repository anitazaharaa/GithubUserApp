package com.example.submissionawalfundamental.view

import android.annotation.SuppressLint
import android.os.Bundle
import android.view.View
import androidx.activity.viewModels
import androidx.annotation.StringRes
import androidx.appcompat.app.AppCompatActivity
import androidx.viewpager2.widget.ViewPager2
import com.bumptech.glide.Glide
import com.example.submissionawalfundamental.R
import com.example.submissionawalfundamental.databinding.ActivityDetailBinding
import com.example.submissionawalfundamental.view.main.SectionPagerAdapter
import com.example.submissionawalfundamental.view.main.UserResponse
import com.example.submissionawalfundamental.view.main.UserViewModel
import com.google.android.material.tabs.TabLayout
import com.google.android.material.tabs.TabLayoutMediator


class DetailActivity : AppCompatActivity() {
    private lateinit var binding: ActivityDetailBinding
    private val UserViewModel by viewModels<UserViewModel>()




    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDetailBinding.inflate(layoutInflater)
        setContentView(binding.root)


        val userLogin = intent.getStringExtra(EXTRA_USER)
        binding.textView2.text = userLogin

       val sectionsPagerAdapter = SectionPagerAdapter(this)
        sectionsPagerAdapter.username = userLogin.toString()

        val viewPager: ViewPager2 = findViewById(R.id.view_pager)
        viewPager.adapter = sectionsPagerAdapter


        val tabs: TabLayout = findViewById(R.id.tabs)
        TabLayoutMediator(tabs, viewPager) { tab, position ->
            tab.text = resources.getString(TAB_TITLES[position])
        }.attach()


        if (userLogin != null) {
            showLoading(true)
            UserViewModel.getUserDetail(userLogin)
            showLoading(false)
        }
        UserViewModel.detailUser.observe(this, {detailUser ->
           setDetailUser(detailUser)
        })
        UserViewModel.isloading.observe(this) {
            showLoading(it)
        }
    }

    private fun setDetailUser(User: UserResponse) {
        Glide.with(this@DetailActivity)
            .load(User?.avatarUrl)
            .into(binding.imgAvatar)

        binding?.apply {
            textView2.text = User?.login
            rvUsername.text = User?.name
            tvFollowingCount.text = User?.following.toString()
            tvFollowerCount.text = User?.followers.toString()
        }

    }

    private fun showLoading(state: Boolean){
        if (state){
            binding.progressBar.visibility= View.VISIBLE
        }
        else{
            binding.progressBar.visibility=View.GONE
        }
    }
    companion object {
        const val EXTRA_USER = "extra_user"

        @StringRes
        private val TAB_TITLES = intArrayOf(
            R.string.tab_text_1,
            R.string.tab_text_2
        )
    }

}



