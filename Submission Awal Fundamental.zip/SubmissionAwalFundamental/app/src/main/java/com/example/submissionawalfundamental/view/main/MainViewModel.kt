package com.example.submissionawalfundamental.view.main

import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.example.submissionawalfundamental.data.response.GithubResponse
import com.example.submissionawalfundamental.data.response.ItemsItem
import com.example.submissionawalfundamental.data.retrofit.ApiConfig
import retrofit2.Call
import retrofit2.Response

class MainViewModel : ViewModel() {

    private val orangoranggithub = MutableLiveData<List<ItemsItem>> ()
    val orangganteng: LiveData<List<ItemsItem>> = orangoranggithub

    val isLoading = MutableLiveData<Boolean>()
    val isloading: LiveData<Boolean> = isLoading

    init {
        findOrangGanteng("r")
    }

    companion object{
        private const val TAG = "MainViewModel"
    }

    fun findOrangGanteng(username: String){
        isLoading.value = true
        val client = ApiConfig.getApiService().getUser(username)
        client.enqueue(object : retrofit2.Callback<GithubResponse> {
            override fun onResponse(
                call: Call<GithubResponse>,
                response: Response<GithubResponse>
            ) {
                isLoading.value = false
                if (response.isSuccessful) {
                    orangoranggithub.value = response.body()?.items
                }else{
                    Log.e(TAG, "onFailure: ${response.message()}")
                }
            }

            override fun onFailure(call: Call<GithubResponse>, t: Throwable) {
                isLoading.value = false
                Log.e(TAG, "onFailure: ${t.message.toString()}")
            }

        })
    }
}