package com.example.submissionawalfundamental

import android.content.Intent
import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.submissionawalfundamental.data.response.ItemsItem
import com.example.submissionawalfundamental.databinding.ItemUserBinding
import com.example.submissionawalfundamental.view.DetailActivity

class UserAdapter(private val userList: List<ItemsItem>) : RecyclerView.Adapter<UserAdapter.UserViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): UserViewHolder {
        val binding = ItemUserBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return UserViewHolder(binding)
    }



    override fun onBindViewHolder(holder: UserViewHolder, position: Int) {
        val dataorang = userList[position]
        Glide.with(holder.itemView.context)
            .load(dataorang.avatarUrl)
            .into(holder.imgAvatar)
        holder.binding.tvUsername.text = dataorang.login
        holder.itemView.setOnClickListener{
            val intentDetail = Intent(holder.itemView.context, DetailActivity::class.java)
            intentDetail.putExtra(DetailActivity.EXTRA_USER, dataorang.login)
            holder.itemView.context.startActivity(intentDetail)
        }
    }

    override fun getItemCount() = userList.size

    class UserViewHolder(var binding: ItemUserBinding) : RecyclerView.ViewHolder(binding.root) {
        val tvUsername: TextView = itemView.findViewById(R.id.tvUsername)
        val imgAvatar: ImageView = itemView.findViewById(R.id.imgAvatar)
    }
}
