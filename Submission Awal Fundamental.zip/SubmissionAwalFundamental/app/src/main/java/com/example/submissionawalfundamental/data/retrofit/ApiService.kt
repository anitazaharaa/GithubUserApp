package com.example.submissionawalfundamental.data.retrofit


import com.example.submissionawalfundamental.data.response.GithubResponse
import com.example.submissionawalfundamental.data.response.ItemsItem
import com.example.submissionawalfundamental.view.main.UserResponse
import retrofit2.Call
import retrofit2.http.GET
import retrofit2.http.Headers
import retrofit2.http.Path
import retrofit2.http.Query

interface ApiService {
    @GET("search/users")
    @Headers("Authorization: token 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")
    fun getUser(
        @Query("q") query: String
    ): Call<GithubResponse>

    @GET("users/{username}")
    @Headers("Authorization: token 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")
    fun getDetailUser(
        @Path("username") username: String?
    ): Call<UserResponse>

    @GET("users/{username}/followers")
    @Headers("Authorization: token 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")
    fun getFollowers(
        @Path("username") username: String?
    ): Call<List<ItemsItem>>

        @GET("users/{username}/following")
        @Headers("Authorization: token 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")
        fun getFollowing(
            @Path("username") username: String?
        ): Call<List<ItemsItem>>

}