package com.example.submissionawalfundamental.view.main

import android.os.Bundle
import android.view.View
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.submissionawalfundamental.UserAdapter
import com.example.submissionawalfundamental.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    private val mainViewModel by viewModels<MainViewModel>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        mainViewModel.orangganteng.observe(this) { users ->
            binding.usersRecyclerview.layoutManager = LinearLayoutManager(this)
            binding.usersRecyclerview.adapter = UserAdapter(users)
        }
        mainViewModel.isLoading.observe(this, {
            showLoading(it)
        })
    }
    private fun showLoading(state: Boolean){
        if (state){
            binding.progressBar.visibility= View.VISIBLE
        }
        else{
            binding.progressBar.visibility=View.GONE
        }




        with(binding) {
            searchView.setupWithSearchBar(searchBar)
            searchView
                .editText
                .setOnEditorActionListener { textView, actionId, event ->
                    searchBar.setText(searchView.text)
                    searchView.hide()
                    mainViewModel.findOrangGanteng(binding.searchBar.text.toString())
                    false
                }


        }

    }
}

